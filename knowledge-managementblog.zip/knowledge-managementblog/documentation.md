# Personal Knowledge Blog - User Guide

## Overview

Your personal knowledge blog is a dual-system setup combining:
- **Hugo** - For writing and managing blog posts in Markdown
- **React + Vite** - For displaying posts in a modern dark-themed interface with knowledge graph visualization

## Table of Contents

1. [Creating New Blog Posts](#creating-new-blog-posts)
2. [Updating the React Display](#updating-the-react-display)
3. [Customizing Your Profile](#customizing-your-profile)
4. [Managing Article Connections](#managing-article-connections)
5. [Using the Knowledge Graph](#using-the-knowledge-graph)
6. [Deploying Your Blog](#deploying-your-blog)

---

## Creating New Blog Posts

### Step 1: Write Your Post in Markdown

Create a new file in the `content/posts/` directory:

```bash
# Example filename: content/posts/my-new-article.md
```

### Step 2: Add Frontmatter

Every post must start with YAML frontmatter:

```markdown
---
title: Your Article Title Here
date: 2025-01-22
draft: false
---

Your article content goes here. Write in Markdown format.

## Subheadings

Use standard Markdown syntax for formatting:
- Lists
- **Bold text**
- *Italic text*
- [Links](https://example.com)
```

### Step 3: Save the File

Save your markdown file in `content/posts/`. The Hugo system will recognize it automatically.

---

## Updating the React Display

After creating a Hugo post, you need to add it to the React app to display it on your website.

### Edit BlogFeed Component

Open `portfolio/src/components/BlogFeed.jsx` and add your new post to the `allPosts` array:

```javascript
const allPosts = [
  // ... existing posts ...
  {
    id: 5,  // Increment the ID
    title: "Your Article Title Here",
    date: "2025-01-22",
    excerpt: "First 2-3 sentences of your article that will appear on the card preview.",
    image: "https://images.unsplash.com/photo-[YOUR-IMAGE-ID]?w=800&q=80",
    tags: ["Tag1", "Tag2", "Tag3"],
    relatedPosts: [1, 2],  // IDs of related articles
    source: "my-new-article.md"  // Your Hugo filename
  }
];
```

### Finding Images

For article images, use [Unsplash](https://unsplash.com/):
1. Search for a relevant image
2. Copy the photo URL
3. Add `?w=800&q=80` to optimize size

---

## Customizing Your Profile

### Update Sidebar Information

Edit `portfolio/src/components/Sidebar.jsx`:

```javascript
// Line 12-14: Change your name and tagline
<h2 className="profile-name">Your Name</h2>
<p className="profile-tagline">Your tagline here</p>

// Line 16-20: Update your bio
<p className="profile-bio">
  Your bio text here. Describe yourself, your work, 
  and what readers can expect from your blog.
</p>
```

### Update Profile Photo

Replace the placeholder image URL:

```javascript
// Line 8
<img 
  src="YOUR_PHOTO_URL_HERE" 
  alt="Profile" 
  className="profile-photo" 
/>
```

### Update Social Links

Edit the social links section:

```javascript
// Lines 23-31
<div className="social-links">
  <a href="https://instagram.com/yourhandle" className="social-icon">
    <span>📷</span>
  </a>
  <a href="https://vk.com/yourhandle" className="social-icon">
    <span>🔵</span>
  </a>
  <a href="https://pinterest.com/yourhandle" className="social-icon">
    <span>📌</span>
  </a>
</div>
```

---

## Managing Article Connections

### Understanding Connections

Articles connect through two methods:

1. **Shared Tags** - Automatically creates connections between articles with the same tags
2. **Manual Links** - Explicit connections you define in the `relatedPosts` array

### Tag Strategy

Choose tags thoughtfully:
- **Broad topics**: "Intellectual Property", "AI", "Business Strategy"
- **Specific themes**: "Copyright", "Patents", "Knowledge Management"
- **Cross-cutting concepts**: "Legal", "Technology", "Innovation"

Articles with 2+ shared tags will have stronger connections in the knowledge graph.

### Manual Related Posts

Use `relatedPosts` to create explicit connections:

```javascript
{
  id: 5,
  title: "New Article",
  // ...
  tags: ["AI", "Ethics"],
  relatedPosts: [1, 3, 4]  // Links to articles 1, 3, and 4
}
```

**Tips:**
- Connect articles that build on each other's ideas
- Link foundational articles to advanced topics
- Create thematic clusters (e.g., all IP law articles)

---

## Using the Knowledge Graph

### Viewing the Graph

1. Click the **🔗 button** at the top of the blog feed
2. The knowledge graph modal opens showing all articles as nodes

### Interacting with the Graph

- **Nodes** (circles) = Articles
- **Lines** (edges) = Connections
  - **Blue thick lines** = Manual `relatedPosts` connections
  - **Gray thin lines** = Shared tag connections

### Clicking Nodes

Click any node to:
- Highlight the article
- View its title
- See all its tags
- Identify its connections

### Graph Behavior

The graph uses physics simulation:
- Nodes repel each other (spread out)
- Connected nodes attract each other (cluster together)
- Related articles naturally group together

---

## Deploying Your Blog

### Option 1: Replit Deployment (Easiest)

1. Click the **Publish** button in Replit
2. Build command: `cd portfolio && npm run build`
3. Public directory: `portfolio/dist`
4. Your site goes live with a `.replit.app` domain

### Option 2: VPS Deployment (Recommended)

#### Requirements:
- VPS server (DigitalOcean, Linode, etc.)
- Domain name (optional)
- GitHub repository

#### Setup Steps:

1. **Prepare Your VPS**
```bash
# SSH into your server
ssh user@your-server-ip

# Install Nginx
sudo apt update
sudo apt install nginx

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install nodejs
```

2. **Build Your Site Locally**
```bash
cd portfolio
npm run build
# This creates the 'dist' folder
```

3. **Upload to VPS**
```bash
# Use SCP to transfer files
scp -r dist/* user@your-server-ip:/var/www/html/
```

4. **Configure Nginx**
```nginx
# /etc/nginx/sites-available/blog
server {
    listen 80;
    server_name yourdomain.com;
    
    root /var/www/html;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

5. **Enable Site**
```bash
sudo ln -s /etc/nginx/sites-available/blog /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Option 3: GitHub Actions Auto-Deploy

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to VPS

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '20'
      
      - name: Install and Build
        run: |
          cd portfolio
          npm install
          npm run build
      
      - name: Deploy to VPS
        uses: easingthemes/ssh-deploy@main
        env:
          SSH_PRIVATE_KEY: ${{ secrets.SSH_PRIVATE_KEY }}
          REMOTE_HOST: ${{ secrets.REMOTE_HOST }}
          REMOTE_USER: ${{ secrets.REMOTE_USER }}
          SOURCE: "portfolio/dist/"
          TARGET: "/var/www/html/"
```

**Set GitHub Secrets:**
- `SSH_PRIVATE_KEY` - Your VPS SSH private key
- `REMOTE_HOST` - Your VPS IP address
- `REMOTE_USER` - Your SSH username

Now every `git push` automatically deploys your site!

---

## Workflow: Adding a New Post

### Complete Process

1. **Write the post**
   ```bash
   # Create new markdown file
   vim content/posts/my-awesome-post.md
   ```

2. **Add frontmatter and content**
   ```markdown
   ---
   title: My Awesome Post
   date: 2025-01-23
   draft: false
   ---
   
   Post content here...
   ```

3. **Update React component**
   - Edit `portfolio/src/components/BlogFeed.jsx`
   - Add new post object to `allPosts` array
   - Include title, date, excerpt, tags, and related posts

4. **Test locally**
   ```bash
   # Server should auto-reload via Vite HMR
   # Check http://localhost:5000
   ```

5. **Commit and push**
   ```bash
   git add .
   git commit -m "Add new post: My Awesome Post"
   git push origin main
   ```

6. **Deploy**
   - If using GitHub Actions: automatic!
   - If using Replit: click Publish
   - If manual VPS: run build and upload

---

## Tips and Best Practices

### Writing Effective Posts

- **First paragraph matters** - It becomes the excerpt on cards
- **Use descriptive titles** - They appear in the knowledge graph
- **Tag consistently** - Use the same tag names across posts
- **Link related content** - Build your knowledge network

### Managing the Knowledge Graph

- Aim for 3-5 tags per article
- Connect at least 2 related posts for each article
- Create "hub" articles that connect multiple topics
- Balance broad and specific tags

### Performance

- Optimize images before uploading
- Keep excerpts under 300 characters
- Limit to 10-15 posts initially (add more gradually)

### Maintenance

- Review connections monthly
- Update related posts when adding new content
- Refresh tag strategy as your blog grows

---

## Setting Up Comments (Giscus)

Your blog is configured to use **Giscus** for comments - a free, spam-resistant commenting system powered by GitHub Discussions.

### Why Giscus?
- ✅ **Free and open-source**
- ✅ **Spam prevention** (requires GitHub login)
- ✅ **Privacy-focused** (no ads, no tracking)
- ✅ **Lightweight** and fast
- ✅ **Dark theme** support

### Setup Steps:

1. **Create a GitHub Repository** (or use an existing one)
   - Make sure it's public
   - Enable Discussions in repository settings

2. **Configure Giscus**
   - Visit [giscus.app](https://giscus.app)
   - Enter your repository name (e.g., `yourusername/blog-repo`)
   - Select "Discussions" category
   - Copy the generated script tag

3. **Update BlogFeed.jsx**
   - Open `portfolio/src/components/BlogFeed.jsx`
   - Find the Giscus script section (around line 347)
   - Replace the placeholder values:
     ```javascript
     data-repo="yourusername/yourrepo"        // Your GitHub repo
     data-repo-id="YOUR_REPO_ID"              // From giscus.app
     data-category="Comments"                  // Your category name
     data-category-id="YOUR_CATEGORY_ID"      // From giscus.app
     ```

4. **Remove placeholder message**
   - Delete the `<div className="comment-placeholder">` section
   - The Giscus widget will appear automatically

### Testing
- Deploy your site
- Visit an article
- You should see the Giscus comment widget
- Test posting a comment (requires GitHub login)

---

## Troubleshooting

### Post not appearing?

1. Check the post is added to `BlogFeed.jsx`
2. Verify the `draft` field is `false` in frontmatter
3. Ensure the file is saved
4. Restart the dev server if needed

### Knowledge graph not showing connections?

1. Verify tags are spelled exactly the same across posts
2. Check `relatedPosts` array contains valid post IDs
3. Ensure at least 2 posts share a tag

### Images not loading?

1. Verify image URLs are accessible
2. Check for HTTPS (not HTTP)
3. Use Unsplash or similar reliable image CDNs

### Comments not showing?

1. Make sure you've configured Giscus with your repository
2. Verify repository is public and has Discussions enabled
3. Check that the repository ID and category ID are correct
4. Clear browser cache and reload

---

## Support and Updates

### File Structure
```
.
├── content/posts/          # Hugo blog posts (markdown)
├── portfolio/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Sidebar.jsx       # Profile sidebar
│   │   │   ├── BlogFeed.jsx      # Article display
│   │   │   └── KnowledgeGraph.jsx # Graph visualization
│   │   └── App.jsx
│   └── dist/              # Built files for deployment
└── documentation.md       # This file
```

### Need Help?

- Check `replit.md` for system architecture
- Review component comments in source files
- Test changes locally before deploying

---

**Last Updated:** January 27, 2025  
**Version:** 1.0
