# Overview

This repository contains two distinct web projects:

1. **React Portfolio Website** (ACTIVE) - A modern, responsive single-page portfolio application built with React 19 and Vite, featuring sections for hero introduction, about/skills, projects showcase, and contact information. Currently running on port 5000.

2. **Hugo Static Blog (IP Spark)** - A blog about intellectual property strategy, AI-generated content, and knowledge management built using the Hugo static site generator with the "Etch" theme. The blog focuses on IP law, business strategy, and innovation in the digital age.

The repository serves as a dual-purpose development environment hosting both a content-focused blog and a personal portfolio site.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## React Single-Page Application (Portfolio) - ACTIVE

**Problem**: Need an interactive, modern portfolio website with smooth animations and responsive design.

**Solution**: React-based SPA using Vite as the build tool and development server.

**Architecture Details**:
- **Framework**: React 19.1.1 with functional components
- **Build Tool**: Vite 7.1.7 for fast development and optimized production builds
- **Component Architecture**: Modular component structure with separate CSS files for each component (Sidebar, BlogFeed, KnowledgeGraph)
- **Development Server**: Configured for Replit environment with WebSocket HMR on port 5000
- **Styling Approach**: Component-scoped CSS with modern features (CSS Grid, Flexbox, animations)
- **State Management**: Component-level state (no external state management library)
- **Location**: `/portfolio/` directory
- **Deployment**: Configured to build React app and serve from `portfolio/dist` directory

**Design Style**: Personal knowledge blog with dark theme inspired by modern blog layouts. Features fixed sidebar profile and scrolling content area, combining personal branding with content discovery. Includes Obsidian-style knowledge graph for visualizing article connections.

**Components**:
- **Sidebar** (Fixed Left): Profile photo (Agostino De Angelis), name, tagline ("Knowledge Flow Architect"), bio, social links (Website, LinkedIn, Email), and CTA buttons linking to projects and contact pages
- **BlogFeed** (Scrolling Right): Article cards with featured images, titles, dates, excerpts, and tag clouds. Includes search bar and knowledge graph toggle.
- **KnowledgeGraph**: Interactive force-directed graph visualization showing article connections through tags, related posts, and manual links. Nodes represent articles, edges show relationships.
- **Search**: Real-time filtering of articles by title, content, and tags

**Profile Information**:
- **Name**: Agostino De Angelis
- **Tagline**: Knowledge Flow Architect
- **Bio**: Father, teacher, programmer investigating the interaction of human mind and new technologies
- **Professional Profile**: https://de-angelis.info
- **Projects**: https://agostinodeangelis.com/projects
- **Contact**: https://agostinodeangelis.com/contact

**Pros**:
- Modern, interactive user experience
- Component reusability and maintainability
- Fast development with HMR
- Optimized production builds
- Fully responsive design

**Cons**:
- Requires JavaScript enabled on client
- More complex build process than static HTML

## Static Site Generation (Hugo Blog)

**Problem**: Need to publish and maintain a professional blog about intellectual property topics with minimal overhead and maximum performance.

**Solution**: Hugo static site generator with markdown-based content management.

**Architecture Details**:
- **Content Structure**: Markdown files in `/content/posts/` and `/content/about/` directories with YAML frontmatter for metadata
- **Theme System**: Uses the "Etch" theme (installed in `/themes/etch/`) for minimal, responsive design
- **Build Output**: Static HTML generated to `/public/` directory for deployment
- **Content Creation**: Python script (`scripts/post.py`) automates creation of new blog posts with proper frontmatter
- **Styling**: CSS-based theming with dark mode support via media queries

**Pros**: 
- No database or server-side processing required
- Extremely fast page loads
- Simple content workflow with markdown
- Version control friendly

**Cons**:
- Requires rebuild for content updates
- Limited dynamic functionality

## Code Quality and Linting

**Solution**: ESLint configuration for React with recommended rules for hooks and refresh patterns.

**Configuration**:
- Uses ESLint 9 flat config format
- React Hooks linting for best practices
- React Refresh plugin for Vite compatibility
- Custom rule to ignore unused variables matching uppercase patterns

# External Dependencies

## React Portfolio Dependencies

### Production Dependencies
- **React**: ^19.1.1 - UI library
- **React DOM**: ^19.1.1 - React rendering for web

### Development Dependencies
- **Vite**: ^7.1.7 - Build tool and dev server
- **@vitejs/plugin-react**: ^5.0.4 - React integration for Vite
- **ESLint**: ^9.36.0 - Code linting
- **@eslint/js**: ^9.36.0 - ESLint core rules
- **eslint-plugin-react-hooks**: ^5.2.0 - React Hooks linting
- **eslint-plugin-react-refresh**: ^0.4.22 - React Fast Refresh linting
- **globals**: ^16.4.0 - Global variables definitions
- **TypeScript Type Definitions**: @types/react and @types/react-dom for TypeScript support

## Hugo Blog Dependencies

- **Hugo Framework**: Version 0.126.1 - Static site generator (installed via Nix)
- **Etch Theme**: Third-party Hugo theme from GitHub (https://github.com/LukasJoswiak/etch)
- **Python 3**: For post creation automation script

# Deployment Considerations

## Portfolio (React + Vite)

### Option 1: Replit Static Deployment
- Build command: `cd portfolio && npm run build`
- Public directory: `portfolio/dist`
- One-click publish from Replit UI

### Option 2: VPS with GitHub Actions (Recommended for production)
The portfolio can be automatically deployed to a VPS using GitHub Actions:

**Benefits**:
- Lower hosting costs ($5-20/month VPS)
- Full control over the server
- Automatic deployment on git push
- Fast static file serving

**Requirements**:
- VPS with web server (Nginx/Apache)
- SSH access configured
- GitHub repository

**Setup Process**:
1. Configure VPS with web server
2. Set up SSH keys for deployment
3. Add GitHub Actions workflow file (`.github/workflows/deploy.yml`)
4. Store VPS credentials as GitHub secrets
5. Push to GitHub → Auto-deploy

See GitHub Actions documentation for Hugo deployment examples (same process applies to static React builds).

### Option 3: Other Platforms
- **Netlify**: Auto-detects Vite, set build directory to `portfolio/dist`
- **Vercel**: Import GitHub repo, auto-configuration
- **GitHub Pages**: Deploy `dist` folder with `gh-pages` package

## Hugo Blog

- The `/public/` directory contains generated static files
- Can be deployed to any static hosting (Netlify, Vercel, GitHub Pages, VPS)
- VPS deployment via GitHub Actions (same workflow as portfolio)
- Replit Static Deployment: Build command `hugo --minify`, public directory `/public/`

# Recent Changes

- **2025-10-27**: Fixed deployment configuration to publish React portfolio instead of Hugo blog (build command updated)
- **2025-10-27**: Reduced knowledge graph physics forces by 60-80% for near-instant settling
- **2025-10-27**: Made knowledge graph nodes clickable to navigate directly to articles
- **2025-10-27**: Added social sharing buttons (Twitter, LinkedIn, Facebook, Email) with branded colors
- **2025-10-27**: Integrated Giscus commenting system with spam prevention (requires GitHub login)
- **2025-10-27**: Created comprehensive Giscus setup documentation
- **2025-10-27**: Personalized sidebar with Agostino De Angelis profile photo, name, and bio
- **2025-10-27**: Added functional links to professional profile, projects, and contact pages
- **2025-10-27**: Updated social icons to Website, LinkedIn, and Email
- **2025-10-27**: Fixed Vite `allowedHosts` configuration for Replit dynamic hostnames
- **2025-10-27**: Created comprehensive documentation.md with usage guide for posts and deployment
- **2025-10-27**: Cleaned up unused portfolio components (About, Contact, Header, Hero, Projects, Skills)
- **2025-10-27**: Redesigned as personal knowledge blog with dark grey theme and fixed sidebar layout
- **2025-10-27**: Implemented Sidebar component with profile, bio, social links, and CTA buttons
- **2025-10-27**: Created BlogFeed component displaying Hugo blog posts as article cards
- **2025-10-27**: Built KnowledgeGraph component with force-directed layout for visualizing article connections
- **2025-10-27**: Added search functionality for filtering articles by title, content, and tags
- **2025-10-27**: Integrated article linking system through tags and related posts
- **2025-10-27**: Applied dark theme (dark grey shades: #0f1115, #1a1d23, #2d3748)
- **2025-10-27**: Made layout responsive (sidebar stacks on mobile)
- **2025-10-27**: Hugo blog setup maintained alongside React app for content management
- **2025-10-27**: Configured Vite for Replit environment (port 5000, WSS HMR, allowedHosts: true)
- **2025-10-27**: Set up Portfolio workflow to serve React application
- **2025-10-27**: Added comprehensive `.gitignore` for Node.js and Hugo projects
