
---
title: "Author"
---

Hi! I'm Agostino De Angelis and I am the author of the blog posts. \
I am passionate about innovation and knowledge management systems, I believe in the value of human creativity over machines and AI. In a word that is increasingly rely on the technical expertise, I give voice to the mental and tactical way to create viable new ideas. \
My professional focus is dedicated to business consulting for intellectual property strategies. You can learn more about me at [my website](https://agostinodeangelis.com).
