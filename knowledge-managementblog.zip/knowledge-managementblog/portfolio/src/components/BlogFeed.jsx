import React, { useState } from 'react';
import KnowledgeGraph from './KnowledgeGraph';
import './BlogFeed.css';

const BlogFeed = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showGraph, setShowGraph] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  
  // Blog posts from Hugo content (/content/posts/)
  const allPosts = [
    {
      id: 1,
      title: "AI-Generated Content: Who Owns the Copyright?",
      date: "2025-01-22",
      excerpt: "The rise of artificial intelligence (AI) is revolutionizing the creative landscape. From generating stunning visuals to composing compelling music and writing captivating stories, AI tools are empowering individuals and businesses to produce content in ways never before imagined. However, this technological leap has also ushered in a new era of complex legal questions, particularly surrounding copyright ownership.",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80",
      tags: ["AI", "Copyright", "Intellectual Property", "Legal"],
      relatedPosts: [2, 3],
      source: "AI-Generated Content.md",
      content: `The rise of artificial intelligence (AI) is revolutionizing the creative landscape. From generating stunning visuals to composing compelling music and writing captivating stories, AI tools are empowering individuals and businesses to produce content in ways never before imagined. However, this technological leap has also ushered in a new era of complex legal questions, particularly surrounding copyright ownership.

## The Copyright Conundrum

The fundamental question at the heart of this debate is: Who owns the copyright to AI-generated content? Is it the developer who created the AI algorithm, the user who prompted the AI, or does the content belong to no one at all?

Traditional copyright law grants ownership to the "author" of a creative work. However, copyright systems worldwide generally require human authorship. This principle is enshrined in law across many jurisdictions, creating a significant challenge when AI is the primary creator.

## Different Legal Perspectives

### United States
The U.S. Copyright Office has taken a clear stance: works created solely by AI, without human creative input, are not eligible for copyright protection. This means AI-generated content could potentially enter the public domain immediately upon creation.

### European Union
The EU has a slightly different approach, focusing on the level of human involvement in the creative process. If a human demonstrates sufficient creative choices in directing the AI, they may be able to claim copyright.

### Practical Implications

For businesses and creators using AI tools:
- Document your creative process and input
- Understand that purely AI-generated content may not be protectable
- Consider hybrid approaches that combine AI assistance with human creativity
- Stay informed as laws evolve to address these new technologies

## Looking Forward

As AI continues to advance, legal frameworks will need to adapt. The challenge is finding a balance between encouraging innovation and protecting the rights of human creators. Until then, anyone using AI to create content should be aware of the current legal uncertainties and plan accordingly.`
    },
    {
      id: 2,
      title: "Intellectual Property Strategy in the Digital Age",
      date: "2021-12-01",
      excerpt: "In today's rapidly evolving digital landscape, protecting intellectual property has become more crucial than ever. This comprehensive guide explores modern IP protection strategies and their impact on business growth. Key areas covered include digital IP protection mechanisms, patent strategy in technology sectors, trademark considerations for global markets, and copyright protection in the digital era.",
      image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&q=80",
      tags: ["IP Strategy", "Digital", "Business", "Protection", "Patents", "Trademarks"],
      relatedPosts: [1, 4],
      source: "ip-strategy-digital-age.md",
      content: `In today's rapidly evolving digital landscape, protecting intellectual property has become more crucial than ever. Companies face unprecedented challenges as technology enables both innovation and infringement at remarkable speeds.

## The Digital IP Landscape

The digital age has transformed how we create, share, and protect intellectual property. Traditional IP frameworks are being tested by new technologies, global connectivity, and the speed of digital commerce.

## Key Protection Mechanisms

### Patents in Technology
Technology patents remain critical for protecting innovations, but the patent landscape is increasingly complex. Companies must navigate:
- Software patentability challenges
- International patent strategies
- Rapid technology obsolescence
- Open source considerations

### Digital Trademarks
Brand protection in the digital age extends beyond traditional markets:
- Domain name strategies
- Social media brand protection
- App store trademark issues
- Global brand consistency

### Copyright in the Digital Era
Digital content creation and distribution present unique copyright challenges:
- Digital rights management
- Fair use in the digital context
- Content licensing models
- Platform liability issues

## Strategic Considerations

Successful IP strategy in the digital age requires:
1. Proactive protection before market entry
2. Regular IP audits and portfolio management
3. Global perspective on IP rights
4. Balance between protection and collaboration
5. Awareness of emerging technologies and their IP implications

## Conclusion

As technology continues to evolve, so must our approach to IP protection. Companies that develop robust, flexible IP strategies will be best positioned to protect their innovations and compete effectively in the digital marketplace.`
    },
    {
      id: 3,
      title: "Business Strategy in the Knowledge Economy",
      date: "2025-01-22",
      excerpt: "The knowledge economy demands a new approach to business strategy. This analysis examines how companies can leverage intellectual assets and knowledge management for strategic advantage. Key topics include identifying and valuing knowledge assets, creating knowledge-based competitive advantages, strategic alignment of IP and business goals, and building learning organizations.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
      tags: ["Business Strategy", "Knowledge Economy", "Intellectual Assets", "Competitive Advantage"],
      relatedPosts: [2, 4],
      source: "business-strategy.md",
      content: `The knowledge economy has fundamentally changed how businesses create and capture value. In this new paradigm, intellectual assets and knowledge management are not just support functions—they are core strategic drivers.

## Understanding Knowledge Assets

Knowledge assets include:
- **Explicit knowledge**: Documented processes, patents, databases
- **Tacit knowledge**: Employee expertise, organizational culture, relationships
- **Structural capital**: Systems, procedures, and organizational capabilities

## Creating Knowledge-Based Competitive Advantage

### Identification and Valuation
The first step is identifying which knowledge assets provide strategic value:
- Core competencies and capabilities
- Proprietary processes and methodologies
- Customer insights and relationships
- Innovation pipelines

### Protection and Leverage
Once identified, these assets must be both protected and leveraged:
- IP protection for innovations
- Knowledge sharing for operational excellence
- Strategic partnerships for knowledge exchange
- Continuous learning and adaptation

## Strategic Alignment

Successful knowledge economy strategies require:
1. **Integration**: Align IP strategy with business strategy
2. **Investment**: Resource allocation to knowledge development
3. **Culture**: Foster knowledge sharing and innovation
4. **Metrics**: Measure knowledge asset performance

## Building Learning Organizations

Organizations that thrive in the knowledge economy share common characteristics:
- Commitment to continuous learning
- Systems for capturing and sharing knowledge
- Incentives aligned with knowledge contribution
- Leadership that values intellectual capital

## The Path Forward

As we move deeper into the knowledge economy, the ability to identify, protect, leverage, and grow intellectual assets will increasingly determine competitive success. Companies must view knowledge management not as a technical challenge but as a strategic imperative.`
    },
    {
      id: 4,
      title: "Knowledge Management Systems: A Strategic Approach",
      date: "2025-01-22",
      excerpt: "Effective knowledge management is a cornerstone of modern business success. This article delves into building robust knowledge management systems that drive organizational growth. We'll explore designing knowledge repositories, implementation of knowledge sharing platforms, best practices for knowledge retention, and measuring knowledge management ROI.",
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80",
      tags: ["Knowledge Management", "Systems", "ROI", "Business Growth", "Knowledge Sharing"],
      relatedPosts: [2, 3],
      source: "knowledge-management-system.md",
      content: `Effective knowledge management is a cornerstone of modern business success. Organizations that can capture, organize, share, and leverage their collective knowledge gain significant competitive advantages.

## Designing Knowledge Repositories

A well-designed knowledge repository serves as the foundation of any KM system:

### Core Components
- **Content management**: Structured storage and retrieval
- **Search functionality**: Powerful, intuitive search capabilities
- **Access controls**: Security and permission management
- **Version control**: Track changes and maintain history

### Best Practices
- User-friendly interfaces that encourage adoption
- Mobile accessibility for modern workforce
- Integration with existing tools and workflows
- Regular content audits and updates

## Implementation of Knowledge Sharing Platforms

### Platform Selection
Choose platforms that match organizational needs:
- Internal wikis for collaborative documentation
- Forums and discussion boards for problem-solving
- Social collaboration tools for real-time sharing
- Learning management systems for training

### Driving Adoption
Technology alone doesn't ensure success. Critical success factors include:
- Executive sponsorship and support
- Clear communication of benefits
- Training and ongoing support
- Recognition and rewards for contribution

## Knowledge Retention Strategies

### Capturing Critical Knowledge
Organizations must proactively capture knowledge before it's lost:
- Exit interviews with departing employees
- Documentation of key processes and procedures
- Mentoring and apprenticeship programs
- Communities of practice

### Preventing Knowledge Loss
- Succession planning
- Cross-training initiatives
- Redundancy in critical roles
- Continuous documentation

## Measuring Knowledge Management ROI

### Key Metrics
- Time saved in information retrieval
- Reduction in duplicate efforts
- Innovation rates and patent filings
- Employee satisfaction and retention
- Customer satisfaction improvements

### Building the Business Case
Demonstrate value through:
- Baseline measurements before implementation
- Regular tracking and reporting
- Success stories and case studies
- Continuous improvement initiatives

## Conclusion

Knowledge management systems are not just technology implementations—they are strategic initiatives that require careful planning, sustained commitment, and continuous evolution. Organizations that approach KM strategically position themselves for sustained success in the knowledge economy.`
    }
  ];

  // Filter posts based on search term
  const posts = searchTerm
    ? allPosts.filter(post => 
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    : allPosts;

  // If an article is selected, show the full article view
  if (selectedPost) {
    return (
      <div className="blog-feed">
        <div className="article-view">
          <button className="back-btn" onClick={() => setSelectedPost(null)}>
            ← Back to Articles
          </button>
          <article className="full-article">
            <div className="article-header">
              <img src={selectedPost.image} alt={selectedPost.title} className="article-hero-image" />
              <div className="article-header-content">
                <h1 className="article-title">{selectedPost.title}</h1>
                <p className="article-date">{selectedPost.date}</p>
                <div className="article-tags">
                  {selectedPost.tags.map((tag, idx) => (
                    <span key={idx} className="tag">{tag}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="article-body">
              {selectedPost.content.split('\n').map((paragraph, idx) => {
                if (paragraph.startsWith('## ')) {
                  return <h2 key={idx}>{paragraph.substring(3)}</h2>;
                } else if (paragraph.startsWith('### ')) {
                  return <h3 key={idx}>{paragraph.substring(4)}</h3>;
                } else if (paragraph.startsWith('- ')) {
                  return <li key={idx}>{paragraph.substring(2)}</li>;
                } else if (paragraph.trim() === '') {
                  return null;
                } else if (paragraph.match(/^\d+\./)) {
                  return <li key={idx}>{paragraph}</li>;
                } else {
                  return <p key={idx}>{paragraph}</p>;
                }
              })}
            </div>
            
            {/* Social Sharing Section */}
            <div className="article-footer">
              <div className="social-sharing">
                <h3>Share this article</h3>
                <div className="share-buttons">
                  <a 
                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(selectedPost.title)}&url=${encodeURIComponent(window.location.href)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="share-btn twitter"
                    title="Share on Twitter"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                    </svg>
                    Twitter
                  </a>
                  <a 
                    href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="share-btn linkedin"
                    title="Share on LinkedIn"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                    LinkedIn
                  </a>
                  <a 
                    href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="share-btn facebook"
                    title="Share on Facebook"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                    Facebook
                  </a>
                  <a 
                    href={`mailto:?subject=${encodeURIComponent(selectedPost.title)}&body=${encodeURIComponent('Check out this article: ' + window.location.href)}`}
                    className="share-btn email"
                    title="Share via Email"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                    </svg>
                    Email
                  </a>
                </div>
              </div>

              {/* Comments Section using Giscus (GitHub Discussions) */}
              <div className="comments-section">
                <h3>Comments</h3>
                <div className="giscus-container">
                  <p className="comment-notice">
                    💬 Comments are powered by GitHub Discussions. You'll need a GitHub account to comment.
                    This helps prevent spam while maintaining privacy.
                  </p>
                  <script
                    src="https://giscus.app/client.js"
                    data-repo="yourusername/yourrepo"
                    data-repo-id="YOUR_REPO_ID"
                    data-category="Comments"
                    data-category-id="YOUR_CATEGORY_ID"
                    data-mapping="pathname"
                    data-strict="0"
                    data-reactions-enabled="1"
                    data-emit-metadata="0"
                    data-input-position="top"
                    data-theme="dark"
                    data-lang="en"
                    crossOrigin="anonymous"
                    async
                  />
                  <div className="comment-placeholder">
                    <p>To enable comments, configure Giscus with your GitHub repository.</p>
                    <p>Instructions are in the documentation.md file.</p>
                  </div>
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>
    );
  }

  return (
    <div className="blog-feed">
      <div className="feed-header">
        <h1 className="feed-title">Write something...</h1>
        <div className="search-controls">
          <input 
            type="text" 
            placeholder="Search articles..." 
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button 
            className="graph-btn" 
            title="View Knowledge Graph"
            onClick={() => setShowGraph(true)}
          >
            Knowledge Graph
          </button>
        </div>
      </div>

      <div className="posts-grid">
        {posts.map((post) => (
          <article 
            key={post.id} 
            className="post-card"
            onClick={() => setSelectedPost(post)}
          >
            <div className="post-image">
              <img src={post.image} alt={post.title} />
              <span className="post-date">{post.date}</span>
            </div>
            <div className="post-content">
              <h2 className="post-title">{post.title}</h2>
              <p className="post-excerpt">{post.excerpt}</p>
              <div className="post-tags">
                {post.tags.map((tag, idx) => (
                  <span key={idx} className="tag">{tag}</span>
                ))}
              </div>
            </div>
          </article>
        ))}
      </div>

      {showGraph && (
        <KnowledgeGraph 
          posts={allPosts} 
          onClose={() => setShowGraph(false)}
          onNodeClick={(post) => setSelectedPost(post)}
        />
      )}
    </div>
  );
};

export default BlogFeed;
