import React from 'react';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <div className="profile-section">
        <div className="profile-image-container">
          <img 
            src="/profile.png" 
            alt="Profile" 
            className="profile-photo" 
          />
        </div>
        
        <h2 className="profile-name">Agostino De Angelis</h2>
        <p className="profile-tagline">Knowledge Flow Architect</p>
        
        <p className="profile-bio">
          Father, teacher, programmer, I investigate the interaction of human mind and the new technologies. 
          You can also see my professional profile here: <a href="https://de-angelis.info" target="_blank" rel="noopener noreferrer" className="bio-link">de-angelis.info</a>
        </p>
        
        <div className="social-links">
          <a href="https://agostinodeangelis.com" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="Website">
            <span>🌐</span>
          </a>
          <a href="http://linkedin.com/agostinodeangelis" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="LinkedIn">
            <span>💼</span>
          </a>
        </div>
        
        <div className="profile-actions">
          <a href="https://agostinodeangelis.com/projects" target="_blank" rel="noopener noreferrer" className="btn-primary">My Work</a>
          <a href="https://agostinodeangelis.com/contact" target="_blank" rel="noopener noreferrer" className="btn-secondary">Contact Me</a>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
