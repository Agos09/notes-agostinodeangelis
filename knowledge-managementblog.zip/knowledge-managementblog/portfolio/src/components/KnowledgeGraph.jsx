import React, { useEffect, useRef, useState } from 'react';
import './KnowledgeGraph.css';

const KnowledgeGraph = ({ posts, onClose, onNodeClick }) => {
  const canvasRef = useRef(null);
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);

  useEffect(() => {
    if (!posts) return;

    // Create nodes from posts
    const graphNodes = posts.map((post, idx) => ({
      id: post.id,
      title: post.title,
      x: Math.random() * 600 + 100,
      y: Math.random() * 400 + 100,
      vx: 0,
      vy: 0,
      tags: post.tags || []
    }));

    // Create edges from related posts and shared tags
    const graphEdges = [];
    posts.forEach((post) => {
      // Connect related posts
      if (post.relatedPosts) {
        post.relatedPosts.forEach((relatedId) => {
          graphEdges.push({
            from: post.id,
            to: relatedId,
            type: 'related'
          });
        });
      }

      // Connect posts with shared tags
      posts.forEach((otherPost) => {
        if (post.id !== otherPost.id && post.tags && otherPost.tags) {
          const sharedTags = post.tags.filter(tag => 
            otherPost.tags.includes(tag)
          );
          if (sharedTags.length > 0) {
            const edgeExists = graphEdges.some(e => 
              (e.from === post.id && e.to === otherPost.id) ||
              (e.from === otherPost.id && e.to === post.id)
            );
            if (!edgeExists) {
              graphEdges.push({
                from: post.id,
                to: otherPost.id,
                type: 'tag',
                tags: sharedTags
              });
            }
          }
        }
      });
    });

    setNodes(graphNodes);
    setEdges(graphEdges);
  }, [posts]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || nodes.length === 0) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Simple force-directed layout simulation
    const simulate = () => {
      // Apply forces (heavily reduced for minimal movement)
      nodes.forEach((node) => {
        // Center gravity (minimal)
        node.vx += (width / 2 - node.x) * 0.0001;
        node.vy += (height / 2 - node.y) * 0.0001;

        // Repulsion between nodes (minimal)
        nodes.forEach((other) => {
          if (node.id !== other.id) {
            const dx = node.x - other.x;
            const dy = node.y - other.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const force = 20 / (dist * dist);
            node.vx += (dx / dist) * force;
            node.vy += (dy / dist) * force;
          }
        });

        // Edge attraction (minimal)
        edges.forEach((edge) => {
          if (edge.from === node.id) {
            const other = nodes.find(n => n.id === edge.to);
            if (other) {
              const dx = other.x - node.x;
              const dy = other.y - node.y;
              node.vx += dx * 0.002;
              node.vy += dy * 0.002;
            }
          }
        });

        // Heavy damping (settles quickly)
        node.vx *= 0.75;
        node.vy *= 0.75;

        // Update position
        node.x += node.vx;
        node.y += node.vy;

        // Keep in bounds
        node.x = Math.max(50, Math.min(width - 50, node.x));
        node.y = Math.max(50, Math.min(height - 50, node.y));
      });

      // Draw
      ctx.clearRect(0, 0, width, height);

      // Draw edges
      edges.forEach((edge) => {
        const fromNode = nodes.find(n => n.id === edge.from);
        const toNode = nodes.find(n => n.id === edge.to);
        if (fromNode && toNode) {
          ctx.beginPath();
          ctx.moveTo(fromNode.x, fromNode.y);
          ctx.lineTo(toNode.x, toNode.y);
          ctx.strokeStyle = edge.type === 'related' ? '#667eea' : '#4a5568';
          ctx.lineWidth = edge.type === 'related' ? 2 : 1;
          ctx.stroke();
        }
      });

      // Draw nodes
      nodes.forEach((node) => {
        const isSelected = selectedNode === node.id;
        ctx.beginPath();
        ctx.arc(node.x, node.y, isSelected ? 12 : 8, 0, Math.PI * 2);
        ctx.fillStyle = isSelected ? '#764ba2' : '#667eea';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = isSelected ? 3 : 2;
        ctx.stroke();

        // Draw label
        ctx.fillStyle = '#ffffff';
        ctx.font = isSelected ? 'bold 12px sans-serif' : '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(
          node.title.length > 30 ? node.title.substring(0, 27) + '...' : node.title,
          node.x,
          node.y + (isSelected ? 25 : 20)
        );
      });
    };

    // Animation loop
    const animate = () => {
      simulate();
      requestAnimationFrame(animate);
    };
    animate();
  }, [nodes, edges, selectedNode]);

  const handleCanvasClick = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Find clicked node
    const clicked = nodes.find((node) => {
      const dx = node.x - x;
      const dy = node.y - y;
      return Math.sqrt(dx * dx + dy * dy) < 12;
    });

    if (clicked) {
      setSelectedNode(clicked.id);
      // Navigate to article if onNodeClick is provided
      if (onNodeClick) {
        const post = posts.find(p => p.id === clicked.id);
        if (post) {
          onNodeClick(post);
          onClose(); // Close graph after clicking
        }
      }
    }
  };

  return (
    <div className="knowledge-graph-modal">
      <div className="graph-container">
        <div className="graph-header">
          <h2>Knowledge Graph</h2>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="graph-canvas"
          onClick={handleCanvasClick}
        />
        {selectedNode && (
          <div className="node-info">
            <h3>{nodes.find(n => n.id === selectedNode)?.title}</h3>
            <div className="node-tags">
              {nodes.find(n => n.id === selectedNode)?.tags.map((tag, idx) => (
                <span key={idx} className="tag">{tag}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default KnowledgeGraph;
