import React from 'react';
import Sidebar from './components/Sidebar';
import BlogFeed from './components/BlogFeed';
import './App.css';

function App() {
  return (
    <div className="App">
      <Sidebar />
      <BlogFeed />
    </div>
  );
}

export default App;
