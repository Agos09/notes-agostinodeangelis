# Personal Portfolio Website

A modern, responsive portfolio website built with React and Vite.

## Features

- **Hero Section**: Eye-catching landing page with gradient background and animated elements
- **About Section**: Showcase your skills and expertise with icon cards
- **Projects Section**: Display your portfolio work with hover effects
- **Contact Section**: Professional contact form and social links
- **Responsive Design**: Looks great on all devices
- **Smooth Animations**: Engaging user experience with CSS animations

## Customization Guide

To personalize your portfolio, edit the following:

### 1. Hero Section (`src/components/Hero.jsx`)
- Replace "Your Name" with your actual name
- Update the title and description
- Add your profile image to replace the placeholder circle

### 2. About Section (`src/components/About.jsx`)
- Customize the about text
- Update skills/services icons and descriptions

### 3. Projects Section (`src/components/Projects.jsx`)
- Add your real projects to the `projects` array
- Update project titles, descriptions, and tags
- Add project images or screenshots

### 4. Contact Section (`src/components/Contact.jsx`)
- Update email, phone, and location
- Add your social media links (GitHub, LinkedIn, Twitter)
- Configure the contact form submission handler

## Running Locally

```bash
cd portfolio
npm install
npm run dev
```

The site will be available at http://localhost:5000

## Building for Production

```bash
npm run build
```

The built files will be in the `dist/` directory.

## Deployment Options

### Option 1: Replit Static Deployment
- Click "Publish" in Replit
- Choose "Static Deployment"
- Build command: `cd portfolio && npm run build`
- Public directory: `portfolio/dist`

### Option 2: VPS with GitHub Actions
See the main project README for instructions on setting up automatic deployment to a VPS using GitHub Actions.

### Option 3: Other Platforms
- **Netlify**: Connect your GitHub repo, set build directory to `portfolio/dist`
- **Vercel**: Import your GitHub repo, Vercel auto-detects Vite
- **GitHub Pages**: Use `gh-pages` package to deploy the `dist` folder

## Tech Stack

- React 19
- Vite 7
- CSS3 (Custom styling with animations)
- Modern ES6+ JavaScript

## Project Structure

```
portfolio/
├── src/
│   ├── components/
│   │   ├── Header.jsx/css    # Navigation bar
│   │   ├── Hero.jsx/css      # Landing section
│   │   ├── About.jsx/css     # About section
│   │   ├── Projects.jsx/css  # Portfolio showcase
│   │   └── Contact.jsx/css   # Contact form
│   ├── App.jsx               # Main app component
│   └── App.css               # Global styles
├── public/                   # Static assets
└── vite.config.js           # Vite configuration
```

## Next Steps

1. **Add Your Content**: Replace all placeholder text with your actual information
2. **Add Images**: Add your profile photo and project screenshots
3. **Customize Colors**: Update the color scheme in the CSS files to match your brand
4. **Wire Contact Form**: Connect the contact form to a backend service (FormSpree, EmailJS, etc.)
5. **Add Analytics**: Consider adding Google Analytics or similar
6. **SEO**: Update the HTML title and meta tags in `index.html`

Enjoy building your portfolio! 🚀
